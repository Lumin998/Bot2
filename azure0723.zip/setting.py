﻿# -*- coding: utf-8 -*-
봇_토큰 = "" #봇의 토큰
관리자아이디 = "1106796839908425759" #라이센스 뽑을 수 있는 사람의 아이디
API_엔드포인트 = "https://discord.com/api"  #건드리지 마세요.
클라이언트_아이디 = "1026536730259632169" #디스코드 개발자 센터 Oauth2 탭에 들어가면 있는 CLIENT ID
클라이언트_시크릿 = "" #디스코드 개발자 센터 Oauth2 탭에 들어가면 있는 CLIENT SECRET
도메인 = "https://recv3.starvend.xyz" #복구봇을 이용할 도메인
포트 = 25565
proxycheck_key = ""
ipqualityscore_key = ""
api_endpoint = "https://discord.com/api"
########### ↓ 건드리지 마세요 ↓ ###########

token = 봇_토큰
admin_id = 관리자아이디
api_endpoint = API_엔드포인트
client_id = 클라이언트_아이디
client_secret = 클라이언트_시크릿
base_url = 도메인
port = 포트

########### ↑ 건드리지 마세요 ↑ ###########
